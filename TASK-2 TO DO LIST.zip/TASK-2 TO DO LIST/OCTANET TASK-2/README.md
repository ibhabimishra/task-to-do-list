# prepared by N jagannath choudhry
# Foundation Project


# To-Do-List

## A Simple To - Do Website!

# To Do List


### *Features*:

* User-friendly
* Local Storage Supported
* Displays current Date and Time
* Responsive, on all devices
* Themes: Users can choose among different themes.
